package com.example.muslimwork.jadwal_sholat

import android.icu.text.SimpleDateFormat
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.muslimwork.R
import com.loopj.android.http.AsyncHttpClient
import com.loopj.android.http.AsyncHttpResponseHandler
import java.util.*

class JadwalSholatActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_jadwal_sholat)

//        setSupportActionBar(toolbar_menu_jadwal_sholat)
//
//        initView()
    }

//    private fun initView() {
//        val c: Date = Calendar.getInstance().time
//        val df = SimpleDateFormat("E, dd MMM", Locale.getDefault())
//        val formattedDate: String = df.format(c)
//
//        tv_date_pray.text = formattedDate
//
//        initGetDataJadwalSholat(c, "jakarta")
//    }
//
//    private fun initGetDataJadwalSholat(date: Date, city: String) {
//        val df = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
//        val formattedData: String = df.format(date)
//
//        val client = AsyncHttpClient()
//        val  url = "https://api.pray.zone/v2/times/day.json?city=$city&date=$formattedData"
//        client.get(url, object : AsyncHttpResponseHandler()) {
//            override fun onSucces(
//                statusCode: Int,
//            )
//        }
//    }
}