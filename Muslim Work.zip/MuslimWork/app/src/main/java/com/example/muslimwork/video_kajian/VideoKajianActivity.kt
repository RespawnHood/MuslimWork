package com.example.muslimwork.video_kajian

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.muslimwork.R

class VideoKajianActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_video_kajian)
    }
}