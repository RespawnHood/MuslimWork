package com.example.muslimwork.home.model

// Kerangka Untuk Data Inspirasi
// Karena Hanya Menampilkan Gambar, Jadi Variabelnya
class InspirationModel {
    var inspirationImage: Int = 0
}